<?php

/**
 * Already Logged In
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="bbp-template-notice info">
	<p><?php _e( 'You are already logged in.', 'mk_framework' ); ?></p>
</div>
